/*
 * Interrupciones.h
 *
 *  Created on: Jul 2, 2023
 *      Author: Informatica
 */

#ifndef INC_INTERRUPCIONES_H_
#define INC_INTERRUPCIONES_H_
#include "stm32f3xx_hal.h"
#include "main.h"
void Timers_Init();

#endif /* INC_INTERRUPCIONES_H_ */
